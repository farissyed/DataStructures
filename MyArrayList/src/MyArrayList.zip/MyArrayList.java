import java.util.ArrayList;
import java.util.Collection;

/**
 * A class that stores a list of objects
 * 
 * @author Faris Syed
 * @version 10/2/18
 */
public class MyArrayList<E> {
    private int size;
    private Object[] values;

    public MyArrayList() {
        size = 0;
        values = new Object[8];
    }

    public MyArrayList(int initialCapacity) {
        size = 0;
        values = new Object[initialCapacity];
    }

    public MyArrayList(Collection<E> c) {
        values = new Object[c.size()];
        addAll( c );
    }

    private void checkIndex( int index ) {
        if ( index > size || index < 0 ) {
            throw new IndexOutOfBoundsException();
        }
    }

    public boolean add( E obj ) {
        add(size, obj);
        return true;
    }

    public void add( int index, E obj ) {
        checkIndex( index );
        values[index] = obj;
        size++;
    }

    public boolean remove( Object obj ) {
        //return obj.equals( remove( indexOf( obj ) ) );
        try {
            remove(indexOf(obj));
        } 
        catch (IndexOutOfBoundsException e) {
            return false;
        }
        return true;
    }

    public E remove( int index ) {
        checkIndex( index );
        Object x = values[index];
        for ( int i = index; i < size - 1; i++ ) {
            values[i] = values[i + 1];
        }
        size--;
        return (E)x;
    }

    public E get( int index ) {
        checkIndex( index );
        return (E)values[index];
    }

    public E set( int index, E obj ) {
        checkIndex( index );
        Object x = values[index];
        values[index] = obj;
        return (E)x;
    }

    public int size() {
        return size;
    }

    public boolean contains( Object obj ) {
        for ( int i = 0; i < size; i++ ) {
            if ( values[i].equals( obj ) ) {
                return true;
            }
        }
        return false;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public String toString() {
        if (isEmpty()) {
            return "[]";
        }
        String result = "[" + values[0].toString();
        for ( int i = 1; i < size; i++ ) {
            result += ", " + values[i].toString();
        }
        return result + "]";
    }

    public void addAll( Collection<E> c ) {
        ensureCapacity( size + c.size() );
        for ( E o : c ) {
            add( o );
        }
    }

    public void clear() {
        for ( int i = 0; i < size; i++ ) {
            values[i] = null;
        }
        size = 0;
    }

    public void ensureCapacity( int minCapacity ) {
        Object[] temp = new Object[values.length];

        if ( minCapacity > values.length ) {
            temp = new Object[minCapacity];
            for ( int i = 0; i < values.length; i++ ) {
                temp[i] = values[i];
            }
            values = temp;
        }  
        
    }

    public int indexOf( Object obj ) {
        for ( int i = 0; i < size; i++ ) {
            if ( values[i].equals( obj ) ) {
                return i;
            }
        }
        return -1;
    }

    public int lastIndexOf( Object obj ) {
        for ( int i = size - 1; i >= 0; i-- ) {
            if ( values[i].equals( obj ) ) {
                return i;
            }
        }
        return -1;
    }

    public void removeRange( int fromIndex, int toIndex ) {
        checkIndex( fromIndex );
        checkIndex( toIndex );
        if ( fromIndex > toIndex ) {
            throw new IndexOutOfBoundsException();
        }
        for ( int i = fromIndex; i < toIndex; i++ ) {
            remove(values[i]);
        }        
    }

    public Object[] toArray() {
        Object[] result = new Object[size];
        for ( int i = 0; i < size; i++ ) {
            result[i] = values[i];
        }
        return result;
    }

    public void trimToSize() {
        values = toArray();
    }

    public boolean equals( ArrayList<E> o ) {
        return ( o.size() == size && o.toString().equals( toString() ) );
    }

}
