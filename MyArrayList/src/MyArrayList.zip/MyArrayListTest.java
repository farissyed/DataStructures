import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * A class that performs tests on methods of MyArrayList
 * 
 * @author Faris Syed
 * @version 10/2/18
 */
public class MyArrayListTest {

    private MyArrayList<String> nullList;
    private MyArrayList<String> numbers;

    @Before
    public void setUp() {
        nullList = new MyArrayList<String>();
        
        numbers = new MyArrayList<>( 5 );
        numbers.add( "One" );
        numbers.add( "Two" );
        numbers.add( "Three" );
        numbers.add( "Four" );
               
    }

    @After
    public void tearDown() {
        nullList.clear();
    }

    @Test
    public void testConstructorInitialCapacity() {
        nullList = new MyArrayList<String>( 5 );
        assertEquals( 0, nullList.size() );
    }

    @Test
    public void testConstructorCollection() {
        Collection<String> collect = new ArrayList<>();
        collect.add( "abc" );
        collect.add( "def" );
        collect.add( "ghi" );
        collect.add( "jkl" );
        collect.add( "mno" );
        collect.add( "pqr" );
        collect.add( "stu" );
        collect.add( "vwx" );
        collect.add( "yz" );
        nullList = new MyArrayList<String>( collect );

        assertEquals( 9, nullList.size() );

    }

    @Test
    public void testAddTrue() {
       assertTrue(numbers.add( "Five" ));
    }
    
    @Test
    public void testAddToIndex() {
        numbers.add( 3, "Five" );
        assertEquals( "Five", numbers.get( 3 ));
    }
    
    @Test (expected = IndexOutOfBoundsException.class)
    public void testAddToIndexError() {
        numbers.add( 5, "Five" );
        assertEquals( "Five", numbers.get( 3 ));
    }
    
    @Test
    public void testRemoveObjectTrue() {
        numbers.add( "Five" );
        assertTrue(numbers.remove( "Four" ));
    }
    
    @Test
    public void testRemoveObjectFalse() {
        numbers.add( "Five" );
        assertFalse(numbers.remove( "Random" ));
    }
    
    @Test
    public void testRemoveIndex() {
        numbers.add( "Five" );
        assertEquals("Four", numbers.remove( 3 ));
    }
    
    @Test (expected = IndexOutOfBoundsException.class)
    public void testRemoveIndexOutOfBounds() {
        numbers.add( "Five" );
        assertEquals("Four", numbers.remove( 5 ));
    }
    
    @Test (expected = IndexOutOfBoundsException.class)
    public void testRemoveIndexOutOfBoundsNegative() {
        numbers.add( "Five" );
        assertEquals("Four", numbers.remove( -1 ));
    }
    
    @Test
    public void testGet() {
        numbers.add( "Five" );
        assertEquals("Four", numbers.get( 3 ));
    }
    
    @Test (expected = IndexOutOfBoundsException.class)
    public void testGetIndexOutOfBoundsNegative() {
        numbers.add( "Five" );
        assertEquals(null, numbers.get( 5 ));
    }
    
    @Test (expected = IndexOutOfBoundsException.class)
    public void testGetIndexOutOfBoundsGreater() {
        numbers.add( "Five" );
        assertEquals(null, numbers.get( -1 ));
    }
    
    @Test
    public void testSet() {
        numbers.add( "Five" );
        assertEquals( "Four", numbers.set( 3, "Set Three" ));
    }
    
    @Test (expected = IndexOutOfBoundsException.class)
    public void testSetIndexOutOfBoundsNegative() {
        numbers.add( "Five" );
        assertEquals( "One", numbers.set( -1, "Set Three" ));
    }
    
    @Test (expected = IndexOutOfBoundsException.class)
    public void testSetIndexOutOfBoundsGreater() {
        numbers.add( "Five" );
        assertEquals( "Five", numbers.set( 5, "Set Greater" ));
    }
    
    @Test
    public void testSize() {
        assertEquals( 4, numbers.size() );
    }
    
    @Test
    public void testContainsTrue() {
        assertTrue( numbers.contains("Four") );
    }
    
    @Test
    public void testContainsFalse() {
        assertFalse( numbers.contains( "Five" ) );
    }
    
    @Test
    public void testIsEmptyTrue() {
        assertTrue( nullList.isEmpty() );
    }
    
    @Test
    public void testIsEmptyFalse() {
        assertFalse( numbers.isEmpty() );
    }
    
    @Test
    public void testToString() {
        assertEquals( "[One, Two, Three, Four]", numbers.toString());
    }
    
    @Test
    public void testToStringEmpty() {
        assertEquals( "[]", nullList.toString() );
    }
    
    @Test
    public void testToStringSingleObj() {
        nullList.add( "Hundred" );
        assertEquals( "[Hundred]", nullList.toString() );
    }
    
    @Test
    public void testAddAll() {
        Collection<String> collect = new ArrayList<>();
        collect.add( "Five" );
        collect.add( "Six" );
        collect.add( "Seven" );
        collect.add( "Eight" );
        collect.add( "Nine" );
        numbers.addAll( collect );
        assertEquals( "[One, Two, Three, Four, Five, Six, Seven, Eight, Nine]", numbers.toString() );
    }
    
    @Test
    public void testClear() {
        numbers.clear();
        assertEquals( 0, numbers.size() );
    }
  
    @Test
    public void testEnsureCapacityLargerThanLen() {
        String temp = numbers.toString();
        numbers.ensureCapacity(7);
        assertEquals(temp, numbers.toString());
    }
    
    @Test
    public void testEnsureCapacityNoChange() {
        String temp = numbers.toString();
        numbers.ensureCapacity(4);
        assertEquals(temp, numbers.toString());
    }
    
    @Test
    public void testIndexOfObjExists() {
        assertEquals( 3, numbers.indexOf( "Four" ) );
    }
    
    @Test
    public void testIndexOfObjDNE() {
        assertEquals( -1, numbers.indexOf( "Seven" ) );
    }
    
    @Test
    public void testLastIndexOfObjExists() {
        nullList.add( "Cookie" );
        nullList.add( "Chips" );
        nullList.add( "Pizza" );
        nullList.add( "Ice Cream" );
        nullList.add( "Cookie" );
        nullList.add( "Chips" );
        nullList.add( "Pizza" );
        assertEquals( 6, nullList.lastIndexOf( "Pizza" ) );
    }
    
    @Test
    public void testLastIndexOfObjDNE() {
        nullList.add( "Cookie" );
        nullList.add( "Chips" );
        nullList.add( "Pizza" );
        nullList.add( "Ice Cream" );
        nullList.add( "Cookie" );
        nullList.add( "Chips" );
        nullList.add( "Pizza" );
        assertEquals( -1, nullList.lastIndexOf( "Carrot" ) );
    }
    
    @Test
    public void testRemoveRange() {
        nullList.add( "Cookie" );
        nullList.add( "Chips" );
        nullList.add( "Pizza" );
        nullList.add( "Ice Cream" );
        nullList.removeRange( 0, 1 );
        assertEquals( "[Chips, Pizza, Ice Cream]", nullList.toString() );
    }
    
    @Test (expected = IndexOutOfBoundsException.class)
    public void testRemoveRangeBadFromIndex() {
        nullList.add( "Cookie" );
        nullList.add( "Chips" );
        nullList.add( "Pizza" );
        nullList.add( "Ice Cream" );
        nullList.removeRange( -1, 3 );
        assertEquals( "[Chips, Pizza, Ice Cream]", nullList.toString() );
    }
    
    @Test (expected = IndexOutOfBoundsException.class)
    public void testRemoveRangeBadToIndex() {
        nullList.add( "Cookie" );
        nullList.add( "Chips" );
        nullList.add( "Pizza" );
        nullList.add( "Ice Cream" );
        nullList.removeRange( 3, 5 );
        assertEquals( "[Chips, Pizza, Ice Cream]", nullList.toString() );
    }
    
    @Test (expected = IndexOutOfBoundsException.class)
    public void testRemoveRangeFromGreaterThanTo() {
        nullList.add( "Cookie" );
        nullList.add( "Chips" );
        nullList.add( "Pizza" );
        nullList.add( "Ice Cream" );
        nullList.removeRange( 3, 2 );
        assertEquals( "[Chips, Pizza, Ice Cream]", nullList.toString() );
    }
    
    @SuppressWarnings( "deprecation" )
    @Test
    public void testToArray() {
        Object[] expected = new Object[numbers.size()];
        for ( int i = 0; i < expected.length; i++ ) {
            expected[i] = numbers.get( i );
        } 
        assertEquals( expected, numbers.toArray() );
    }
    
    @Test
    public void testTrimToSize() {
        nullList.trimToSize();
        assertTrue( nullList.isEmpty() );
    }
    
    @Test
    public void testEqualsTrue() {
        ArrayList<String> equalNumbers = new ArrayList<>(Arrays.asList("One", "Two", "Three", "Four"));
        assertTrue(numbers.equals( equalNumbers ));
    }
    
    @Test
    public void testEqualFalse() {
        ArrayList<String> unequalNumbers = new ArrayList<>(Arrays.asList("One", "Two", "Three"));
        assertFalse(numbers.equals( unequalNumbers ));
    }
}
