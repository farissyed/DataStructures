import java.util.ArrayList;
import java.util.Collection;

/**
 * A class that stores a list of objects
 * 
 * @author Faris Syed
 * @version 10/2/18
 */
public class MyArrayList<E> {
    private int size;
    private Object[] values;

    /**
     * Default Constructor
     */
    public MyArrayList() {
        size = 0;
        values = new Object[8];
    }

    /**
     * Constructor taking in initial capacity of background array
     * @param initialCapacity
     */
    public MyArrayList(int initialCapacity) {
        size = 0;
        values = new Object[initialCapacity];
    }

    /**
     * Constructor taking in a collection of items to store in MyArrayList
     * @param c
     */
    public MyArrayList(Collection<E> c) {
        values = new Object[c.size()];
        addAll( c );
    }

    /**
     * Checks if index is valid
     * @param index
     * @throws IndexOutOfBoundsException if index is greater than size or less than 0
     */
    private void checkIndex( int index ) {
        if ( index > size || index < 0 ) {
            throw new IndexOutOfBoundsException();
        }
    }

    /**
     * Adds obj to end of MyArrayList
     * @param obj item to be added
     * @return true
     */
    public boolean add( E obj ) {
        add(size, obj);
        return true;
    }

    /**
     * Adds obj to index in MyArrayList
     * @param index position of item to be added
     * @param obj item to be added
     */
    public void add( int index, E obj ) {
        checkIndex( index );
        values[index] = obj;
        size++;
    }

    /**
     * Removes obj from MyArrayList
     * @param obj
     * @return true if object is removed, false if IndexOutOfBounds is thrown
     */
    public boolean remove( Object obj ) {
        //return obj.equals( remove( indexOf( obj ) ) );
        try {
            remove(indexOf(obj));
        } 
        catch (IndexOutOfBoundsException e) {
            return false;
        }
        return true;
    }

    /**
     * Removes object from an index
     * @param index
     * @return object that was removed
     */
    public E remove( int index ) {
        checkIndex( index );
        Object x = values[index];
        for ( int i = index; i < size - 1; i++ ) {
            values[i] = values[i + 1];
        }
        size--;
        return (E)x;
    }

    /**
     * Returns the object at index
     * @param index
     * @return object at index
     */
    public E get( int index ) {
        checkIndex( index );
        return (E)values[index];
    }

    /**
     * Replaces an object at index for obj        
     * @param index
     * @param obj
     * @return the object that was replaced
     */
    public E set( int index, E obj ) {
        checkIndex( index );
        Object x = values[index];
        values[index] = obj;
        return (E)x;
    }

    /**
     * Size of MyArrayList
     * @return size of MyArrayList
     */
    public int size() {
        return size;
    }

    /**
     * Returns true if list contains obj
     * @param obj
     * @return true if contains obj, false if not
     */
    public boolean contains( Object obj ) {
        for ( int i = 0; i < size; i++ ) {
            if ( values[i].equals( obj ) ) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns true if the size of MyArrayList is 0
     * @return true when size of MyArrayList is 0
     */
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * Converts MyArrayList to a String
     * @return MyArrayList as a String
     */
    public String toString() {
        if (isEmpty()) {
            return "[]";
        }
        String result = "[" + values[0].toString();
        for ( int i = 1; i < size; i++ ) {
            result += ", " + values[i].toString();
        }
        return result + "]";
    }

    /**
     * Adds a collection to MyArrayList
     * @param c Collection of objects
     */
    public void addAll( Collection<E> c ) {
        ensureCapacity( size + c.size() );
        for ( E o : c ) {
            add( o );
        }
    }

    /**
     * Clears all objects in a MyArrayList
     */
    public void clear() {
        for ( int i = 0; i < size; i++ ) {
            values[i] = null;
        }
        size = 0;
    }

    /**
     * Ensures capacity so that objects can be added
     * @param minCapacity 
     */
    public void ensureCapacity( int minCapacity ) {
        Object[] temp = new Object[values.length];

        if ( minCapacity > values.length ) {
            temp = new Object[minCapacity];
            for ( int i = 0; i < values.length; i++ ) {
                temp[i] = values[i];
            }
            values = temp;
        }  
        
    }

    /**
     * Returns first index where obj is found
     * @param obj
     * @return the first index of obj, -1 if obj is not found
     */
    public int indexOf( Object obj ) {
        for ( int i = 0; i < size; i++ ) {
            if ( values[i].equals( obj ) ) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Returns last index where obj is found
     * @param obj
     * @return the last index of obj, -1 if obj is not found
     */
    public int lastIndexOf( Object obj ) {
        for ( int i = size - 1; i >= 0; i-- ) {
            if ( values[i].equals( obj ) ) {
                return i;
            }
        }
        return -1;
    }
    
    /**
     * Removes the elements from one index to another
     * @param fromIndex
     * @param toIndex
     */
    public void removeRange( int fromIndex, int toIndex ) {
        checkIndex( fromIndex );
        checkIndex( toIndex );
        if ( fromIndex > toIndex ) {
            throw new IndexOutOfBoundsException();
        }
        for ( int i = fromIndex; i < toIndex; i++ ) {
            remove(values[i]);
        }        
    }

    /**
     * Converts MyArrayList to Array type
     * @return Object[]
     */
    public Object[] toArray() {
        Object[] result = new Object[size];
        for ( int i = 0; i < size; i++ ) {
            result[i] = values[i];
        }
        return result;
    }

    /**
     * Deletes excess cells of values background array
     */
    public void trimToSize() {
        values = toArray();
    }

    /**
     * Returns true if MyArrayList is equal to ArrayList o
     * @param o
     * @return true if MyArrayList is equal to ArrayList o, false otherwise
     */
    public boolean equals( ArrayList<E> o ) {
        return ( o.size() == size && o.toString().equals( toString() ) );
    }

}
